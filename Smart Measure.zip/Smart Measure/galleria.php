<!DOCTYPE HTML>

<html>
	<head>
		<title>Smart-Measure</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
		
		 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>PHP File Uploader</title>

    <!-- Bootstrap core CSS -->
    <link href="boostrap/css/bootstrap.min.css" rel="stylesheet">
	
							<meta charset="utf-8">
							<meta http-equiv="X-UA-Compatible" content="IE=edge">
							<title>PHP File Uploader</title>

							<!-- Bootstrap core CSS -->
							<link href="boostrap/css/bootstrap.min.css" rel="stylesheet">
	
	</head>
	<body>
		<div class="page-wrap">

		
			<!-- Nav -->
				<nav id="nav">
					<?php include ("nav.php"); ?>
				</nav>

				
				
			<!-- Main -->
				<section id="main">

					<!-- Banner -->
						<section id="banner">
							<div class="inner">
								<h1> Welcome Back 
								
								
								<form action="#" method="post">
								
										<?php
											session_start();
											
											echo "".$_SESSION["Username"]."<br>";
											
										?>
										
									</form>
									
									
								<br> This is Your Personal Gallery </h1>
								<!-- <p>Application that measure something</p> -->
								
								<ul class="actions">
									<!-- <li><a href="#contact" class="button alt scrolly big"> Login </a></li> -->
									<!-- <li><a href="registrati.html" href="#contact" class="button alt scrolly big">Registrati</a></li> -->
								</ul>
							</div>
						</section>
					
					<!--  GALLERIA GIA FATTA PROVO A CANCELLARLA
						<section id="galleries">

							
								<div class="gallery">
									<header class="special">
										<h2>What's New</h2>
									</header>
									<div class="content">
										<div class="media">
											<a href="images/fulls/01.jpg"><img src="images/thumbs/01.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/05.jpg"><img src="images/thumbs/05.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/09.jpg"><img src="images/thumbs/09.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/02.jpg"><img src="images/thumbs/02.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/06.jpg"><img src="images/thumbs/06.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/10.jpg"><img src="images/thumbs/10.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/03.jpg"><img src="images/thumbs/03.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/07.jpg"><img src="images/thumbs/07.jpg" alt="" title="This right here is a caption." /></a>
										</div>
									</div>
									<footer>
										<a href="gallery.html" class="button big">Full Gallery</a>
									</footer>
								</div>
								</section> 
								
								-->
								
								
								
						
						  
							
						   
						  

						  

							<!-- Static navbar -->
							
							<div class="navbar navbar-default navbar-static-top">
							  <div class="container">
								<div class="navbar-header" >
								  <a class="navbar-brand"  href="galleria.php">PHP File Uploader</a>
								</div>
							  </div>
							</div>


							<div class="container">
							
								<div class="row">
								   <?php 
									//scan "uploads" folder and display them accordingly
								   $folder = "uploads";
								   $results = scandir('uploads');
								   foreach ($results as $result) {
									if ($result === '.' or $result === '..') continue;
								   
									if (is_file($folder . '/' . $result)) {
										echo '
										<div class="col-md-3">
											<div class="thumbnail">
												<img src="'.$folder . '/' . $result.'" alt="...">
													<div class="caption">
													<p><a href="remove.php?name='.$result.'" class="btn btn-danger btn-xs" role="button">Remove</a></p>
												</div>
											</div>
										</div>';
									}
								   }
								   ?>
								</div>
								
								

								  <div class="row">
									<div class="col-lg-12">
									
									   <form class="well" action="upload.php" method="post" enctype="multipart/form-data">
										  <div class="form-group">
											<label for="file">Select a file to upload</label>
											
											
											<input type="file" name="file">
											
											<p class="help-block">Only jpg,jpeg,png and gif file with maximum size of 1 MB is allowed.</p>
										  </div>
										  <input type="submit" class="btn btn-lg btn-primary" value="Upload">
										  
										  <!-- <a href="welcomeback.html" class="button"  >Return To Home</a></li> -->
										  
										</form>
									</div>
								  </div>
							</div> <!-- /container -->

						  
						



  

    

  

								
						

					<!-- Contact -->
						<section id="contact">
							<!-- Social -->
								<div class="social column">
									<h3>About Me</h3>
									<p>Mus sed interdum nunc dictum rutrum scelerisque erat a parturient condimentum potenti dapibus vestibulum condimentum per tristique porta. Torquent a ut consectetur a vel ullamcorper a commodo a mattis ipsum class quam sed eros vestibulum quisque a eu nulla scelerisque a elementum vestibulum.</p>
									<p>Aliquet dolor ultricies sem rhoncus dolor ullamcorper pharetra dis condimentum ullamcorper rutrum vehicula id nisi vel aptent orci litora hendrerit penatibus erat ad sit. In a semper velit eleifend a viverra adipiscing a phasellus urna praesent parturient integer ultrices montes parturient suscipit posuere quis aenean. Parturient euismod ultricies commodo arcu elementum suspendisse id dictumst at ut vestibulum conubia quisque a himenaeos dictum proin dis purus integer mollis parturient eros scelerisque dis libero parturient magnis.</p>
									<h3>Follow Me</h3>
									<ul class="icons">
										<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
										<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
										<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
									</ul>
								</div>

							  
								<div class="column">
									<h3> Hai effettuato il Login come :  </h3>
									
									<form action="#" method="post">
										<?php
											
											
											
											echo "".$_SESSION["Username"]."<br>";
										
										?>
										<br>
										
									</form>
									<ul class="actions">
											
											<li><a href="index.html" > <input value="Esci" class="button" type="submit"></a> </li>
										</ul> 
								</div>
							
						</section>

					<!-- Footer -->
						<footer id="footer">
							<div class="copyright">
								&copy; Untitled Design: <a href="https://templated.co/">TEMPLATED</a>. Images: <a href="https://unsplash.com/">Unsplash</a>.
							</div>
						</footer>
				</section>
		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.poptrox.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>