<?php 
session_start();


 
	   $myfile = fopen("account.txt", "r") or die("Impossibile accedere!"); 
       $account=fread($myfile,filesize("account.txt"));
       $arrayUtentePsw =explode (";", $account);
	   
	   for($i=0;$i<count($arrayUtentePsw);$i++){
		 $utenti[$i]=substr($arrayUtentePsw[$i],0,strpos($arrayUtentePsw[$i],"-"));
		 $psw[$i]=substr($arrayUtentePsw[$i],strpos($arrayUtentePsw[$i],"-")+1,strlen($arrayUtentePsw[$i]));
	   }
	
	   $utenteForm = $_POST["Username"];
	   $passwordForm = $_POST["Psw"];
	   
	   if(in_array($utenteForm,$utenti))
	   {
		   if(strcmp($passwordForm,$psw[array_search($utenteForm,$utenti)])==0)
		   {
			  //include("welcomeback.php");
			  //if( !isset( $_SESSION["Username"])  )
			{						
				$Username=$_POST["Username"];				
				$_SESSION["Username"] = $Username;
				
			}
			  header("location: welcomeback.php");
		   }
		   else
		   {
			  include("PagineAggiuntive\pswerrata.html");
		   }
	   }
	   else
	   {
		   include("PagineAggiuntive\userNonTrovato.html");
	   }
	  
?>