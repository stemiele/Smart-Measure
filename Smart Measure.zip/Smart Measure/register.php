<?php
	   $myfile = fopen("account.txt", "a") or die("Impossibile accedere!"); 
       $account=fread($myfile,filesize("account.txt"));
       $arrayUtentePsw =explode (";", $account);
	   
	   for($i=0;$i<count($arrayUtentePsw);$i++){
		 $utenti[$i]=substr($arrayUtentePsw[$i],0,strpos($arrayUtentePsw[$i],"-"));
		 $psw[$i]=substr($arrayUtentePsw[$i],strpos($arrayUtentePsw[$i],"-")+1,strlen($arrayUtentePsw[$i]));
	   }
	
	   $utenteForm = $_POST["Username"];
	   $passwordForm1 = $_POST["Psw1"];
	   $passwordForm2 = $_POST["Psw2"];
	   
	   if(in_array($utenteForm,$utenti))
	   {
			include("PagineAggiuntive\Utentegiaregistrato.html");
	   }
	   else
	   {
		   if(strcmp($passwordForm1,$passwordForm2)==0)
		   {
			   $stringaDaScrivere=$utenteForm."-".$passwordForm1.";";
			   fwrite($myfile,$stringaDaScrivere);
			  include("PagineAggiuntive\PaginaInizialeRegistrazione.php");
		   }
		   else 
		   {
			  include("PagineAggiuntive\PasswordNonCorrisponde.html");
		   }
			   
	   }


?>