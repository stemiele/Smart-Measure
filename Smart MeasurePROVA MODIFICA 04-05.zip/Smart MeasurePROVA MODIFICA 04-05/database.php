<!DOCTYPE HTML>
<!--
	Snapshot by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->

<html>
	<head>
		<title>Generic - Snapshot by TEMPLATED</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>
		<div class="page-wrap">

			<!-- Nav -->
				<nav id="nav">
					<?php include ("nav.php"); ?>
				</nav>
			
			<!-- Main -->
				<section id="main">

					<!-- Header -->
						<header id="header">
							<div> <span>DATABASE </span></div>
						</header>

					<!-- Section -->
						<section>
							<div class="inner">
								<header>
									 <h1> YOUR DATABASE </h1>
								
									
								</header>
											<?php
		
												//File PHP che stampa l'elenco delle misurazioni
												
												//session_start();
												//$username = $_SESSION["username"];
												$conn = new mysqli("localhost","root","","smart_measure");
												
												//$sqlIdUtente = "SELECT ID FROM utenti WHERE username = '$username'";  
												//$resultIdUtente = $conn->query($sqlIdUtente);
												//while(($row = $resultIdUtente->fetch_assoc()))
												//{
												//	$idUtente = $row["ID"];
												//}
												
												//$_SESSION["id"] = $idUtente;
												$sql = "SELECT * FROM misurazione";
												$result = $conn->query($sql);
												if($result->num_rows > 0)
												{
													echo "<table border=1>";
													echo "<tr><td><b>ID</b></td><td><b>Altezza</b></td><td><b>Larghezza</b></td><td><b>Descrizione</b></td><td><b>Nome Immagine</b></td><td></td><tr>";
													while(($row = $result->fetch_assoc()))
													{  
														// Creo la tabella per impaginare bene l'elenco delle case
														echo "<tr>";   
														$idProdotto = $row["ID"];
														echo "<td>" .$row["ID"]. "</td>";
														echo "<td>" .$row["altezza"]. "</td>";
														echo "<td>" .$row["larghezza"]. "</td>";
														echo "<td>" .$row["descrizione"]. "</td>";
														$img=$row["nome_img"];
														$path="uploads/$img";
														if (file_exists($path)) 
															echo "<td><a href='uploads/$img'>" .$row["nome_img"]. "</a></td>";
														else																
															 echo "<td>".$row["nome_img"]. " <b>Immagine mancante!</b>"."<a href='galleria.php#upload'>"."  Aggiungi"."</a></td>";
															
														//echo "<td>" .$row["anno"]. "</td>";
														echo "<td> <a href=elimina.php?msg=$idProdotto> <img src='carrellino.jpg'> </a> </td>";  //Collegamento all'immagine 
														echo "</tr>";
													}
													echo "</table>";
													
													
												}
											?>
								<!--<p>Faucibus parturient mus phasellus vestibulum suspendisse dui vel ridiculus nibh diam placerat tellus scelerisque facilisi mus vestibulum arcu mus praesent in blandit. Conubia ullamcorper cum rhoncus vitae dapibus venenatis integer in donec egestas lacus nibh vestibulum habitasse accumsan parturient malesuada sociis auctor scelerisque vehicula urna eu proin euismod. Id facilisi suspendisse parturient leo mus condimentum natoque scelerisque ullamcorper odio tristique ultricies arcu ac condimentum facilisi scelerisque class commodo. Scelerisque sagittis magna mi duis iaculis id erat pharetra vestibulum condimentum hac suspendisse tempor leo aliquet penatibus parturient donec parturient parturient. Vehicula suspendisse sem a adipiscing est ad donec ultricies senectus magnis convallis a fringilla adipiscing vulputate dui elementum diam ipsum eleifend condimentum placerat facilisi viverra mollis scelerisque. Commodo cum vestibulum hendrerit sit condimentum at rutrum vulputate scelerisque erat convallis himenaeos consequat a hac ultrices nam vel suspendisse nascetur dictum vulputate sed at.</p>
								<h2>Ultricies Senectus Magnis</h2>
								<p>Scelerisque sagittis magna mi duis iaculis id erat pharetra vestibulum condimentum hac suspendisse tempor leo aliquet penatibus parturient donec parturient parturient. Vehicula suspendisse sem a adipiscing est ad donec ultricies senectus magnis convallis a fringilla adipiscing vulputate dui elementum diam ipsum eleifend condimentum placerat facilisi viverra mollis scelerisque. Commodo cum vestibulum hendrerit sit condimentum at rutrum vulputate scelerisque erat convallis himenaeos consequat a hac ultrices nam vel suspendisse nascetur dictum vulputate sed at.</p>
								<section class="columns double">
									<div class="column">
										<span class="image left special"><img src="images/pic01.jpg" alt="" /></span>
										<h3>Parturient Consequat Neque</h3>
										<p>
											Adipiscing dis a mus a convallis condimentum molestie penatibus iaculis pulvinar vestibulum enim lacus suscipit mi dictumst hendrerit sit condimentum at rutrum vulputate vestibulum habitasse nam fusce a nascetur. Ut ullamcorper suspendisse malesuada tempus vestibulum commodo habitasse suspendisse magnis.
										</p>
									</div>
									<div class="column">
										<span class="image left special"><img src="images/pic02.jpg" alt="" /></span>
										<h3>Ridiculus Torquent Quam Accumsan</h3>
										<p>
											At sem phasellus elit class dapibus lectus posuere donec morbi in cras commodo faucibus ipsum vehicula fringilla. Risus hendrerit sit condimentum at rutrum vulputate fringilla dis curae metus ipsum imperdiet vulputate sapien dolorem ligula sapien curae consequat vestibulum urna. Nulla vulputate cum augue non arcu.
										</p>
									</div>
								</section>
							</div>
						</section> -->

					<!-- Contact -->
						<section id="contact">
							<!-- Social -->
								<div class="social column">
									<h3>About Me</h3>
									<p>Mus sed interdum nunc dictum rutrum scelerisque erat a parturient condimentum potenti dapibus vestibulum condimentum per tristique porta. Torquent a ut consectetur a vel ullamcorper a commodo a mattis ipsum class quam sed eros vestibulum quisque a eu nulla scelerisque a elementum vestibulum.</p>
									<p>Aliquet dolor ultricies sem rhoncus dolor ullamcorper pharetra dis condimentum ullamcorper rutrum vehicula id nisi vel aptent orci litora hendrerit penatibus erat ad sit. In a semper velit eleifend a viverra adipiscing a phasellus urna praesent parturient integer ultrices montes parturient suscipit posuere quis aenean. Parturient euismod ultricies commodo arcu elementum suspendisse id dictumst at ut vestibulum conubia quisque a himenaeos dictum proin dis purus integer mollis parturient eros scelerisque dis libero parturient magnis.</p>
									<h3>Follow Me</h3>
									<ul class="icons">
										<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
										<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
										<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
									</ul>
								</div>

							<!-- Form -->
							
								<div class="column">
									<?php
											if(isset($_GET["msg"]))
												echo "<font color='red'>".$_GET['msg']."</font>";

										?>
									<h3>Aggiungi Misurazione al Database</h3>
									<form action="aggiungi.php" method="post">
										<div class="field half first">
											<label for="name">Altezza</label>
											<input name="altezza" id="altezza" type="text" placeholder="Altezza">
										</div>
										<div class="field half">
											<label for="email">Larghezza</label>
											<input name="larghezza" id="larghezza" type="text" placeholder="Larghezza">
										</div>
										<div class="field">
											<label for="message">Descrizione</label>
											<textarea name="descrizione" id="descrizione" rows="6" placeholder="Descrizione"></textarea>
										</div>
										<div class="field half">
											<label for="email">Nome immagine</label>
											<input name="img" id="img" type="text" placeholder="nome.jpg">
										</div>
										<ul class="actions">
											<li><input value="Aggiungi" class="button" type="submit"></li>
										</ul>
										
									</form>
								</div>

						</section>

					<!-- Footer -->
						<footer id="footer">
							<div class="copyright">
								 &copy Stefano Miele , Smart-Measure:  <a href="https://github.com/stemiele/Smart-Measure"> GitHub Project </a>. Images: <a href="https://unsplash.com/">Unsplash</a>.
							</div>
						</footer>
				</section>
		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.poptrox.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>