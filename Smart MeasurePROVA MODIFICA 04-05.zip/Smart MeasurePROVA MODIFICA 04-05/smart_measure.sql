-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Creato il: Mag 10, 2017 alle 10:00
-- Versione del server: 10.1.16-MariaDB
-- Versione PHP: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_measure`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `misurazione`
--

CREATE TABLE `misurazione` (
  `ID` int(11) NOT NULL,
  `altezza` int(11) NOT NULL,
  `larghezza` int(11) NOT NULL,
  `materiale` varchar(32) NOT NULL,
  `descrizione` text NOT NULL,
  `nome_img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `misurazione`
--

INSERT INTO `misurazione` (`ID`, `altezza`, `larghezza`, `materiale`, `descrizione`, `nome_img`) VALUES
(2, 20, 100, '', 'bho', 'ciao.jpg'),
(3, 90, 3, '', 'bhshdioasj', 'Marcolino.png'),
(5, 234, 234, '', 'PRovaassaaaaaa', 'michelaa'),
(6, 234, 5767, '', 'qwefwefwefwef', 'images.jpg'),
(7, 20, 20, '', 'Logo', 'Immaggdgdsfine.png'),
(8, 124312, 12312, '', 'Lo sfondo del nostro sito', 'bannerMONDO.jpg');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `ID` int(11) NOT NULL,
  `nome` varchar(32) NOT NULL,
  `cognome` varchar(32) NOT NULL,
  `email` varchar(64) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`ID`, `nome`, `cognome`, `email`, `username`, `password`) VALUES
(1, '', '', '', 'qwe', 'efe6398127928f1b2e9ef3207fb82663'),
(2, '', '', '', 'ste', '76d80224611fc919a5d54f0ff9fba446'),
(3, '', '', '', 'stee', '76d80224611fc919a5d54f0ff9fba446');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `misurazione`
--
ALTER TABLE `misurazione`
  ADD PRIMARY KEY (`ID`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `misurazione`
--
ALTER TABLE `misurazione`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
