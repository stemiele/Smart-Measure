<?php



$conn = new mysqli("localhost","root","","smart_measure");  //Connessione
session_start();
$username=$_SESSION['Username'];
if(isset($_POST['submit1']))
{
	
	
	
	if(!empty($_POST['user']) && !empty($_POST['password']) && !empty($_POST['confpassword']) || !empty($_POST['user']) && !empty($_POST['nome']) || !empty($_POST['user']) && !empty($_POST['cognome'])|| !empty($_POST['user']) && !empty($_POST['email'])|| !empty($_POST['user']) && !empty($_POST['password'])|| !empty($_POST['user']) && !empty($_POST['confpassword']) ||
		!empty($_POST['password']) && !empty($_POST['nome']) || !empty($_POST['password']) && !empty($_POST['cognome'])|| !empty($_POST['password']) && !empty($_POST['email']) || !empty($_POST['confpassword']) && !empty($_POST['nome']) || !empty($_POST['confpassword']) && !empty($_POST['cognome'])|| !empty($_POST['confpassword']) && !empty($_POST['email']))
	{
		include("PagineAggiuntive\ErroreModificaInsieme.php");
	}
	else
	{
		if(!empty($_POST['nome']))
		{
			
			$nome=$_POST['nome'];
			$sql = "UPDATE utenti SET nome='$nome' WHERE username='$username'";
			if ($conn->query($sql) === TRUE)//mysqli_query($conn, $sql2)
			{
				header("location:welcomeback.php");
			}
			else 
			{
				include("PagineAggiuntive\ErroreModifica.php");
			}
												
		}
		if(!empty($_POST['cognome']))
		{
			$cognome=$_POST['cognome'];
			$sql = "UPDATE utenti SET cognome='$cognome' WHERE username='$username'";
			if ($conn->query($sql) === TRUE)//mysqli_query($conn, $sql2)
				header("location:welcomeback.php");
			else 
			{
				include("PagineAggiuntive\ErroreModifica.php");
			}
		}
		if(!empty($_POST['email']))
		{
			$email=$_POST['email'];
			$sql = "UPDATE utenti SET email='$email' WHERE username='$username'";
			if ($conn->query($sql) === TRUE)//mysqli_query($conn, $sql2)
				header("location:welcomeback.php");
			else 
			{
				include("PagineAggiuntive\ErroreModifica.php");
			}
		}
		if(!empty($_POST['user']))
		{
			$username2=$_POST['user'];
			//controllo se � gi� presente uno username uguale
			$query="select ID from utenti where username='$username2'";
			$ris=mysqli_query($conn,$query);
			if($row=mysqli_fetch_assoc($ris))
			{
				include("PagineAggiuntive\ErroreModificaUtente.php");
			}
			else
			{
				
				$query= "select ID from utenti where username='$username'";
				$risultato=mysqli_query($conn,$query);
				if($row=mysqli_fetch_assoc($risultato))
				{
					$id=$row['ID'];
					$sql = "UPDATE utenti SET username='$username2' WHERE ID='$id'";
					if ($conn->query($sql) === TRUE)//mysqli_query($conn, $sql2)
					{
						$_SESSION['username']=$username2;
						$msg=urldecode("".$_SESSION['username']);
						include("PagineAggiuntive\indexModifica.php");
					}
					else 
					{
						include("PagineAggiuntive\ErroreModifica.php");
					}
				}
			}
		}
		if(!empty($_POST['password']) && !empty($_POST['confpassword']))
		{
			$pass1=md5($_POST['password']);
			$pass2=md5($_POST['confpassword']);
			
			if(strcmp($pass1,$pass2)!=0)
			{
				include("PagineAggiuntive\ErroreModificaPassword.php");
			}	
				else 
				{
					$sql = "UPDATE utenti SET password='$pass1' WHERE username='$username'";
					if ($conn->query($sql) === TRUE)//mysqli_query($conn, $sql2)
					header("location:welcomeback.php");
				}
			}
		}
	}
	




?>