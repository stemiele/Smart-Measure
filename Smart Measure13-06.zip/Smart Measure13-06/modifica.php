<?php



$conn = new mysqli("localhost","root","","smart_measure");  //Connessione
session_start();

//if(isset($_SESSION["Id2"]))
	//echo "<font color='red'>".$_SESSION['Id2']."</font>";

$id = $_SESSION["Id2"];

if(isset($_POST['submit1']))
{
	
	
		if(!empty($_POST['altezza']))
		{
			
			$altezza=$_POST['altezza'];
			$sql = "UPDATE misurazione SET altezza='$altezza' WHERE ID='$id'";
			if ($conn->query($sql) === TRUE)//mysqli_query($conn, $sql2)
			{
				header("location:database.php");
			}
			else 
			{
				include("PagineAggiuntive\ErroreModifica.php");
			}
												
		}
		if(!empty($_POST['larghezza']))
		{
			$larghezza=$_POST['larghezza'];
			$sql = "UPDATE misurazione SET larghezza='$larghezza' WHERE ID='$id'";
			if ($conn->query($sql) === TRUE)//mysqli_query($conn, $sql2)
				header("location:database.php");
			else 
			{
				include("PagineAggiuntive\ErroreModifica.php");
			}
		}
		if(!empty($_POST['materiale']))
		{
			$materiale=$_POST['materiale'];
			$sql = "UPDATE misurazione SET materiale='$materiale' WHERE ID='$id'";
			if ($conn->query($sql) === TRUE)//mysqli_query($conn, $sql2)
				header("location:database.php");
			else 
			{
				include("PagineAggiuntive\ErroreModifica.php");
			}
		}
		if(!empty($_POST['descrizione']))
		{
			$descrizione=$_POST['descrizione'];
			$sql = "UPDATE misurazione SET descrizione='$descrizione' WHERE ID='$id'";
			if ($conn->query($sql) === TRUE)//mysqli_query($conn, $sql2)
				header("location:database.php");
			else 
			{
				include("PagineAggiuntive\ErroreModifica.php");
			}
		}
		
		if(!empty($_POST['img']))
		{
			$img=$_POST['img'];
			$sql = "UPDATE misurazione SET nome_img='$img' WHERE ID='$id'";
			if ($conn->query($sql) === TRUE)//mysqli_query($conn, $sql2)
				header("location:database.php");
			else 
			{
				include("PagineAggiuntive\ErroreModifica.php");
			}
		}
}
	
	




?>