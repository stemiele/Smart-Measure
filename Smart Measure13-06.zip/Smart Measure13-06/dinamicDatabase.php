<?php
												session_start();
												
												//File PHP che stampa l'elenco delle misurazioni
												
												//session_start();
												//$username = $_SESSION["username"];
												$conn = new mysqli("localhost","root","","smart_measure");
												$output='';
												//$sqlIdUtente = "SELECT ID FROM utenti WHERE username = '$username'";  
												//$resultIdUtente = $conn->query($sqlIdUtente);
												//while(($row = $resultIdUtente->fetch_assoc()))
												//{
												//	$idUtente = $row["ID"];
												//}
												
												//$_SESSION["id"] = $idUtente;
												
												if(isset($_POST["query"]))
												{
													$search = mysqli_real_escape_string($conn, $_POST["query"]);
													 $query = "
													  SELECT * FROM misurazione 
													  WHERE ID LIKE '%".$search."%'
													  OR altezza LIKE '%".$search."%' 
													  OR larghezza LIKE '%".$search."%' 
													  OR materiale LIKE '%".$search."%'
													  OR descrizione LIKE '%".$search."%'
													  OR nome_img LIKE '%".$search."%'
													  OR IdUtente LIKE '%".$search."%'
													 ";
												}
												else
												{
													 $query = "
													  SELECT * FROM misurazione ORDER BY ID
													 ";
												}
												
												$result = $conn->query($query);
												if($result->num_rows > 0)
												{
													$output.="<div class='table-responsive'>
													<table border=1>
													<tr><td><b>ID</b></td><td><b>Altezza</b></td><td><b>Larghezza</b></td><td><b>Materiale</b></td></td><td><b>Descrizione</b></td><td><b>Nome Immagine</b></td><td><b>Elimina</b></td><td><b></b></td><td><b>Utente</b></td><tr>";
													while(($row = $result->fetch_assoc()))
													{  
														$idProdotto = $row["ID"];
														// Creo la tabella per impaginare bene l'elenco delle case
														$output.="<tr><td>" .$row["ID"]. "</td>
														<td>" .$row["altezza"]. "</td>
														<td>" .$row["larghezza"]. "</td>
														<td>" .$row["materiale"]. "</td>
														<td>" .$row["descrizione"]. "</td>";
														
														$img=$row["nome_img"];
														$path="uploads/$img";
														if (file_exists($path)) 
															$output.= "<td><a href='uploads/$img'>" .$row["nome_img"]. "</a></td>";
														else																
															$output.="<td>".$row["nome_img"]. " <b>Immagine mancante!</b>"."<a href='galleria.php#upload'>"."  Aggiungi"."</a></td>";
															
														//echo "<td>" .$row["anno"]. "</td>";
														//Collegamento all'immagine 
														$output.="<td> <a href=elimina.php?msg=$idProdotto> <img src='carrellino.jpg'> </a> </td>"; 
														$output.="<td> <a href=calcola.php?msg=$idProdotto> Calcola Piastrelle </a> </td>";	
														$output.="<td>" .$row["IdUtente"]. "</td>";
														
														$output.="</tr>";
													}
													
													echo $output;
													
												}
												else
												{
													$output.='<tr>
																<td colspan="4">Data not Found</td>
															</tr>';
												}
												$output.='</table
															</div>;'
											?>