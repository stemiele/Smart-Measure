					<ul>
						<li><a href="welcomeback.php" class="active"><span class="icon fa-home"></span></a></li>
						<li><a href="galleria.php"><span class="icon fa-camera-retro"></span></a></li>
						<li><a href="database.php"><span class="icon fa-file-text-o"></span></a></li>
					</ul>