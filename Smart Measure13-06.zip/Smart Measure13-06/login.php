<?php 

	session_start();
       $utenteForm = $_POST["Username"];
	   $passwordForm = md5($_POST["Psw"]);
	   $_SESSION["Username"]= $_POST["Username"];
	   $conn = new mysqli("localhost","root","","smart_measure");
	   if(!empty($utenteForm) && !empty($passwordForm))
	   {
		   $sql2 = "SELECT username FROM utenti WHERE username = '$utenteForm'";
		   $result = $conn->query($sql2);
			if($result->num_rows == 0)
			{
				//header("location: PagineAggiuntive\pswerrata.html");
				include("PagineAggiuntive\Login-UserNonTrovato.html");
			}
			else
			{
				$sql = "SELECT * FROM utenti WHERE username = '$utenteForm' AND password = '$passwordForm'";
				$result2 = $conn->query($sql);
				
					if($result2->num_rows == 0)
						include("PagineAggiuntive\Login-PasswordErrata.html");
					else
					{
						header("location:welcomeback.php");
						$_SESSION["Username"] = $_POST["Username"];
					}
			}
			
		}
		else
		{
			include("PagineAggiuntive\Login-CompilaTuttiCampi.html");
		}
	
		

 /* session_start();

		$utenteForm = $_POST["Username"];
	    $passwordForm = $_POST["Psw"];
	   
 
	   $myfile = fopen("account.txt", "r") or die("Impossibile accedere!"); 
       $account=fread($myfile,filesize("account.txt"));
       $arrayUtentePsw =explode (";", $account);
	   
	   for($i=0;$i<count($arrayUtentePsw);$i++){
		 $utenti[$i]=substr($arrayUtentePsw[$i],0,strpos($arrayUtentePsw[$i],"-"));
		 $psw[$i]=substr($arrayUtentePsw[$i],strpos($arrayUtentePsw[$i],"-")+1,strlen($arrayUtentePsw[$i]));
	   }
	
	  
	   if(in_array($utenteForm,$utenti))
	   {
		   if(strcmp($passwordForm,$psw[array_search($utenteForm,$utenti)])==0)
		   {
			  //include("welcomeback.php");
			  //if( !isset( $_SESSION["Username"])  )
			{						
				$Username=$_POST["Username"];				
				$_SESSION["Username"] = $Username;
				
			}
			  header("location: welcomeback.php");
		   }
		   else
		   {
			  include("PagineAggiuntive\pswerrata.html");
		   }
	   }
	   else
	   {
		   include("PagineAggiuntive\userNonTrovato.html");
	   }
	  */
	  
?>