<?php

	//File PHP per l'aggiunta delle case nel DB
	session_start();
	$misAltezza = $_POST["altezza"];
	$misLarghezza = $_POST["larghezza"];
	$misDescrizione = $_POST["descrizione"];
	$misMarmo = $_POST["materiale"];
	$nomeImmagine= $_POST["img"];
	$Utente=$_SESSION["Username"];
	
	$esiste = false;
	$conn = new mysqli("localhost","root","","smart_measure");  //Connessione
	if(!empty($misAltezza) && !empty($misLarghezza) && !empty($misDescrizione) && !empty($nomeImmagine))
	{
				$sql = "INSERT INTO misurazione (ID, altezza, larghezza ,materiale, descrizione , nome_img , IdUtente) VALUES (NULL ,'$misAltezza', '$misLarghezza' ,'$misMarmo', '$misDescrizione', '$nomeImmagine','$Utente')";
				$conn->query($sql);
				header("location:database.php");
	}
			else
			{
				$msg=urlencode("<h2>Attenzione : Compilare tutti i campi!</h2>");
				header("location:database.php".'?msg='.$msg);
			}
		
?>