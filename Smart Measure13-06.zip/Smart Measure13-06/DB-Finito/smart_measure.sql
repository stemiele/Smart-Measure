-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2017 at 01:40 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_measure`
--

-- --------------------------------------------------------

--
-- Table structure for table `misurazione`
--

CREATE TABLE `misurazione` (
  `ID` int(11) NOT NULL,
  `altezza` int(11) NOT NULL,
  `larghezza` int(11) NOT NULL,
  `materiale` varchar(32) NOT NULL,
  `descrizione` text NOT NULL,
  `nome_img` varchar(100) NOT NULL,
  `IdUtente` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `misurazione`
--

INSERT INTO `misurazione` (`ID`, `altezza`, `larghezza`, `materiale`, `descrizione`, `nome_img`, `IdUtente`) VALUES
(20, 200, 250, 'Ardesia', 'Lastra di Ardesia colore Grigio Scuro', 'Ardesia1.jpg', 'Ste_Miele'),
(21, 300, 200, 'Marmo', 'Marmo Grigio Carmico', 'Marmo1.jpg', 'Tia_Franco'),
(22, 150, 400, 'Marmo', 'Marmo Arancio di selva', 'Marmo2.jpg', 'RossiRoberto'),
(23, 300, 300, 'Gneiss', 'Gneis Grigio , per esterni', 'Gneiss.jpg', 'Mic_Parlati'),
(24, 200, 400, 'Marmo', 'Marmo colore verde petrolio', 'Marmo3.jpg', 'Ric_Miele'),
(25, 400, 500, 'Legno', 'Lastra di legno multistrato okume marino impiallacciato con varie essenze legnose.', 'Legno1.jpg', 'LoryGio57'),
(26, 200, 200, 'Marmo', 'Marmo Pregiato color viola con sfumature ', 'Marmo8.jpg', 'Ste_Miele'),
(27, 210, 254, 'Marmo', 'Marmo Color nero', 'Marmo4.jpg', 'Sa_Fenu'),
(28, 421, 325, 'Granito', 'Granito classico Grigio , Marrone e Bianco', 'Granito2.jpg', 'RossiRoberto'),
(29, 241, 312, 'Altro', '                    ', 'Immagine.jpg', 'Ste_Miele'),
(30, 356, 245, 'Marmo', 'Marmo di colore Rosso', 'Marmo9.jpg', 'Ste_Miele'),
(31, 325, 199, 'Granito', 'Granito Comune Rosso , Nero e Bianco', 'Granito1.jpg', 'Ste_Miele');

-- --------------------------------------------------------

--
-- Table structure for table `utenti`
--

CREATE TABLE `utenti` (
  `ID` int(11) NOT NULL,
  `nome` varchar(32) NOT NULL,
  `cognome` varchar(32) NOT NULL,
  `email` varchar(64) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `utenti`
--

INSERT INTO `utenti` (`ID`, `nome`, `cognome`, `email`, `username`, `password`) VALUES
(1, 'qwe', 'qwe', 'qwe@gmail.com', 'qwe', '76d80224611fc919a5d54f0ff9fba446'),
(2, 'Lorenzo', 'Giordano', 'Lory777@gmail.com', 'LoryGio57', '76d80224611fc919a5d54f0ff9fba446'),
(4, 'Maurizio', 'Pisciottu', 'salmo@gmail.com', 'salmo', '76d80224611fc919a5d54f0ff9fba446'),
(7, 'Stefano', 'Miele', 'miele.stefano.98@gmail.com', 'Ste_Miele', '76d80224611fc919a5d54f0ff9fba446'),
(8, 'Mattia', 'Franco', 'mattia.franco@gmail.com', 'Tia_Franco', '76d80224611fc919a5d54f0ff9fba446'),
(9, 'Riccardo', 'Miele', 'Riccardo@gmail.com', 'Ric_Miele', '76d80224611fc919a5d54f0ff9fba446'),
(10, 'Samuele', 'Fenu', 'fenu@gmail.com', 'Sa_Fenu', '76d80224611fc919a5d54f0ff9fba446'),
(11, 'Michela', 'Parlati', 'michela@gmail.com', 'Mic_Parlati', '76d80224611fc919a5d54f0ff9fba446'),
(12, 'Matteo', 'Vernocchi', 'matteo@gmail.com', 'Vernoo98', '76d80224611fc919a5d54f0ff9fba446'),
(13, 'Roberto', 'Rossi', 'rossi@gmail.com', 'RossiRoberto', '76d80224611fc919a5d54f0ff9fba446'),
(14, 'Graziano', 'Brambilla', 'GB@gmail.com', 'Gra_Bra', '76d80224611fc919a5d54f0ff9fba446'),
(15, 'Chester', 'Bennington', 'Linkin@gmail.com', 'ChesterLP', '76d80224611fc919a5d54f0ff9fba446'),
(16, 'Fabrizio', 'Verdi', 'FV@gmail.com', 'fabri_v', '76d80224611fc919a5d54f0ff9fba446');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `misurazione`
--
ALTER TABLE `misurazione`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `misurazione`
--
ALTER TABLE `misurazione`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `utenti`
--
ALTER TABLE `utenti`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
