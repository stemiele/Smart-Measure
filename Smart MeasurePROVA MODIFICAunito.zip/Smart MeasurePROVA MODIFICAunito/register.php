<?php

	session_start();
	$nomeUtente = $_POST["Username"];
	$password1 = md5($_POST["Psw1"]);
	$password2 = md5($_POST["Psw2"]);
	$email = $_POST["email"];
	$cognomeForm = $_POST["cognome"];
	$nomeForm = $_POST["nome"];
	$esiste = false;
	if(!empty($nomeUtente) && !empty($password1)  && !empty($password2)  && !empty($email) && !empty($cognomeForm) && !empty($nomeForm))
	   {
			if(strcmp($password1,$password2)!=0)
			{
				//echo "Le due password devono essere uguale <br>";
				include("PagineAggiuntive\Reg-PasswordNonCorrisponde.html");
			}
			else
			{
			$conn = new mysqli("localhost","root","","smart_measure");
			$sqlControllo = "SELECT * from utenti";
			$result = $conn->query($sqlControllo);
				if($result->num_rows > 0)
				{
					while(($row = $result->fetch_assoc()))
					{
						if(strcmp($row["username"],$nomeUtente)==0 )
						{
							$esiste = true;
							break;
						}
					}
					if($esiste==false) // && !empty($email)
					{
						$sql = "INSERT INTO utenti (ID,username,password) VALUES (NULL,'$nomeUtente','$password1')";
						$conn->query($sql);
						include("PagineAggiuntive\Reg-AvvenutaRegistrazione.php");
					}
					else
					{
						include("PagineAggiuntive\Reg-UtenteGiaRegistrato.html");
					}
				}
				else
				{
					$sql = "INSERT INTO utenti (ID,username, password) VALUES (NULL,'$nomeUtente', '$password1')";
					$conn->query($sql);
					include("PagineAggiuntive\Reg-AvvenutaRegistrazione.php");
				}
			}
	   }
	   else 
	   {
		   include("PagineAggiuntive\Reg-CompilaTuttiCampi.php");
	   }


	   
	
	

?>