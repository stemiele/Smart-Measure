
<!DOCTYPE HTML>
<?php

session_start();


?>
<html>
	<head>
		<title>Smart-Measure</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
		
		<!-- Latest compiled and minified CSS -->
				<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' integrity='sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u' crossorigin='anonymous'>

				<!-- Optional theme -->
				<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css' integrity='sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp' crossorigin='anonymous'>

				<!-- Latest compiled and minified JavaScript -->
				<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js' integrity='sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa' crossorigin='anonymous'></script>
				
		
		 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>PHP File Uploader</title>

    <!-- Bootstrap core CSS -->
    <link href="boostrap/css/bootstrap.min.css" rel="stylesheet">
	
	
	</head>
	<body>
		<div class="page-wrap">

		
			<!-- Nav -->
				<nav id="nav">
					<?php include ("nav.php"); ?>
				</nav>

				
				
			<!-- Main -->
				<section id="main">

					<!-- Banner -->
						<section id="banner">
							<div class="inner">
								<h1> Bentornato 
								
								<form action="#" method="post">
								
										<?php 
										if( !isset( $_SESSION["Username"])  )
										{		
											header("location: login.php");									
										   //if($_POST["Username"]=="")
											//session_start();
											
											//$Username=$_POST["Username"];
											
											//$_SESSION["Username"] = $Username;
											
										}
											
											echo "".$_SESSION["Username"]."";
											
											
										?>
									</form>
								<h1> Smart-Measure </h1>
								<p>Applicazione che misura lastre di diversi Materiali</p>
								<ul class="actions">
									<!-- <li><a href="#contact" class="button alt scrolly big"> Login </a></li> -->
									<!-- <li><a href="registrati.html" href="#contact" class="button alt scrolly big">Registrati</a></li> -->
								</ul>
							</div>
						</section>
					
					
						<section id="galleries">

							<div class="gallery">
								
						<!--  			<header class="special">
										<h2>What's New</h2>
									</header>
									<div class="content">
										<div class="media">
											<a href="images/fulls/01.jpg"><img src="images/thumbs/01.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/05.jpg"><img src="images/thumbs/05.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/09.jpg"><img src="images/thumbs/09.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/02.jpg"><img src="images/thumbs/02.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/06.jpg"><img src="images/thumbs/06.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/10.jpg"><img src="images/thumbs/10.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/03.jpg"><img src="images/thumbs/03.jpg" alt="" title="This right here is a caption." /></a>
										</div>
										<div class="media">
											<a href="images/fulls/07.jpg"><img src="images/thumbs/07.jpg" alt="" title="This right here is a caption." /></a>
										</div>
									</div>
									<footer>
										<a href="gallery.html" class="button big">Full Gallery</a>
									</footer>
								</div>
								</section> 
								
								-->
								
                        <div >
						
								 <form action="galleria.php" method="post">
									<footer>
										<ul class="actions">
											<li><input value="Mostra la Galleria" class="button big" type="submit"></li>
										</ul>
									</footer>
										
								</form>

						</div>
						
						

					<!-- Contact -->
						<section id="contact">
							<!-- Social -->
								<div class="social column">
									<h3></h3>
									 <img width="200" height="200" style="margin-left:00px;"src="images/Logo.png" class="attachment-medium" alt="sondaggio-questionario">
									<h3>Follow Me</h3>
									<ul class="icons">
										<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
										<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
										<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
									</ul>
								</div>

							  
								<div class="column">
								
								
							<div class='row'>
							 
							<div class="col-lg-4">
								<img width="200" height="200" style="margin-left:0px;"src="images/utente.png" class="attachment-medium" >
								 <br>
							<br>
							
								<div class="panel panel-primary" style="width:200%;">
									<div class="panel-heading">
										Account Utente
									</div>
									<div class="panel-body">
									<!--<h1> Account Utente </h1>-->
									 <?php 
									$conn = new mysqli("localhost","root","","smart_measure");  //Connessione
									 $username=$_SESSION['Username'];
									 $sql="select nome,cognome,email,username from utenti where username='$username'";
									 $risultato=mysqli_query($conn,$sql);
									 if($row = $risultato->fetch_assoc())
									 {
										echo "<p>Nome: <b>".$row['nome']."</b></p>";
										echo "<p>Cognome: <b>".$row['cognome']."</b></p>";
										echo "<p>E-Mail: <b>".$row['email']."</b></p>";
										echo "<p>Username: <b>".$row['username']."</b></p>";
									 }
									 ?>
									 </div>
									 <br>
								</div>
							</div>		 
							</div>
							<br></br>
									<form action="welcomebackModifica.php">
											<input type="submit" value="Modifica Account">
									</form>
									<br>
									<br>
									<ul class="actions">
											
											<li><a href="index.php" > <input value="Esci" class="button" type="submit"></a> </li>
										</ul> 
								</div>
							
						</section>

					<!-- Footer -->
						<footer id="footer">
							<div class="copyright">
								 &copy Stefano Miele , Smart-Measure:  <a href="https://github.com/stemiele/Smart-Measure"> GitHub Project </a>. 
							</div>
						</footer>
				</section>
		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.poptrox.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>