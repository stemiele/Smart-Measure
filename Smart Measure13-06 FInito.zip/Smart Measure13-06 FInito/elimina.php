<html>
	<body>
		<?php
		
			//File PHP che gestisce l'eliminazione di un Record 
			session_start();  
			$conn = new mysqli("localhost","root","","smart_measure");   //Connessione
			$IdMisurazione = $_GET["msg"];
			$sql= "DELETE FROM misurazione WHERE ID='$IdMisurazione'";   //Elimina dal DB la casa con il Codice indicato da noi
			$result = $conn->query($sql);
			// echo "Casa eliminata con successo.";  //Messaggio che ti esce
				
					header("location:database.php");
					
							
			
		?>
		<!-- <html>
		<body>
		<form action="prodotti.php" method="post">         
			<input type="submit" value="Torna all'elenco delle case">   Bottone che ti fa tornare all'elenco 
		</body>
		</form>		
		</html> >
</html> -->