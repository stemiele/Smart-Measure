<?php	
	
	// Create connection
	$conn = new mysqli("localhost", "root","","smart_measure");
	// Check connection
	if ($conn->connect_error) {
		die("Connessione fallita: " . $conn->connect_error);
	} 
	
?>